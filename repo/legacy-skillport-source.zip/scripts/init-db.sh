#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
source "$SCRIPT_DIR/lib/storage.sh"
DB="$(agmsg_db_path)"
DB_DIR="$(dirname "$DB")"
mkdir -p "$DB_DIR"

# Idempotent and safe to run concurrently. When a leader fans a job out to N
# members against a fresh/override store (see #106), every send.sh races to
# initialize. Running unconditionally with IF NOT EXISTS (rather than guarding
# on the file's existence) means a process that sees the DB file but not yet
# its schema still ends up with a usable table. See #114.

# WAL is a persistent, one-time DB property and only an optimization. Changing
# the journal mode wants exclusive access, so a concurrent set on a brand-new
# DB can return "database is locked" even with a busy_timeout — set it
# best-effort; whichever initializer wins makes it stick for everyone.
agmsg_sqlite "$DB" "PRAGMA journal_mode=WAL;" >/dev/null 2>&1 || true

# Schema. IF NOT EXISTS + the busy_timeout from agmsg_sqlite make a concurrent
# first-time creation a no-op for the losers rather than an "already exists"
# abort.
agmsg_sqlite "$DB" <<'SQL'
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  message_id TEXT,
  realm TEXT NOT NULL DEFAULT 'local',
  team TEXT NOT NULL,
  from_agent TEXT NOT NULL,
  to_agent TEXT NOT NULL,
  thread TEXT,
  kind TEXT NOT NULL DEFAULT 'message',
  reply_to TEXT,
  body TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'delivered',
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
  read_at TEXT,
  handled_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_unread ON messages(team, to_agent, read_at) WHERE read_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_history ON messages(team, created_at DESC);
SQL

# Migrate stores created before realm-aware routing. SQLite has no
# ADD COLUMN IF NOT EXISTS, so inspect the schema before each additive change.
ensure_column() {
  local name="$1" definition="$2"
  if ! agmsg_sqlite "$DB" "SELECT 1 FROM pragma_table_info('messages') WHERE name='$name';" | grep -q 1; then
    agmsg_sqlite "$DB" "ALTER TABLE messages ADD COLUMN $name $definition;"
  fi
}

ensure_column message_id "TEXT"
ensure_column realm "TEXT NOT NULL DEFAULT 'local'"
ensure_column thread "TEXT"
ensure_column kind "TEXT NOT NULL DEFAULT 'message'"
ensure_column reply_to "TEXT"
ensure_column status "TEXT NOT NULL DEFAULT 'delivered'"
ensure_column handled_at "TEXT"

agmsg_sqlite "$DB" <<'SQL'
CREATE UNIQUE INDEX IF NOT EXISTS idx_message_id ON messages(message_id) WHERE message_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_realm_inbox ON messages(realm, team, to_agent, read_at) WHERE read_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_thread ON messages(realm, team, thread, created_at);
SQL

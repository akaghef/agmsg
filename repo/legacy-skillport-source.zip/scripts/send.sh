#!/usr/bin/env bash
set -euo pipefail

# Usage: send.sh <team> <from> <to> <message> [realm] [thread] [kind] [reply_to]

TEAM="${1:?Usage: send.sh <team> <from> <to> <message>}"
FROM="${2:?Missing from agent}"
TO="${3:?Missing to agent}"
BODY="${4:?Missing message body}"
REALM="${5:-local}"
THREAD="${6:-}"
KIND="${7:-message}"
REPLY_TO="${8:-}"
MESSAGE_ID="${AGMSG_MESSAGE_ID:-$(date -u +%Y%m%dT%H%M%SZ)-$FROM-$$-${RANDOM:-0}}"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
source "$SCRIPT_DIR/lib/storage.sh"
DB="$(agmsg_db_path)"

bash "$SCRIPT_DIR/init-db.sh" >/dev/null

sql_quote() { printf '%s' "$1" | sed "s/'/''/g"; }
INSERT="INSERT INTO messages (message_id, realm, team, from_agent, to_agent, thread, kind, reply_to, body, status) VALUES ('$(sql_quote "$MESSAGE_ID")', '$(sql_quote "$REALM")', '$(sql_quote "$TEAM")', '$(sql_quote "$FROM")', '$(sql_quote "$TO")', '$(sql_quote "$THREAD")', '$(sql_quote "$KIND")', '$(sql_quote "$REPLY_TO")', '$(sql_quote "$BODY")', 'delivered');"

# Retry once after ensuring the schema. Under a concurrent first-write fan-out
# (leader → N members against a fresh/override store), one process can see the
# DB file exist before the winning initializer has finished creating the table,
# so its INSERT would hit "no such table". init-db.sh is idempotent + uses the
# busy_timeout, so re-running it waits for the schema, then the INSERT lands.
# See #114.
if ! agmsg_sqlite "$DB" "$INSERT" 2>/dev/null; then
  bash "$SCRIPT_DIR/init-db.sh" >/dev/null
  agmsg_sqlite "$DB" "$INSERT"
fi

echo "message_id=$MESSAGE_ID realm=$REALM team=$TEAM to=$TO status=delivered"

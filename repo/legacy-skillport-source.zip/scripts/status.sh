#!/usr/bin/env bash
set -euo pipefail

# Usage: status.sh <message_id> <handled|failed>
MESSAGE_ID="${1:?Usage: status.sh <message_id> <handled|failed>}"
STATUS="${2:?Missing status}"
case "$STATUS" in handled|failed) ;; *) echo "status must be handled or failed" >&2; exit 2 ;; esac

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
source "$SCRIPT_DIR/lib/storage.sh"
DB="$(agmsg_db_path)"
bash "$SCRIPT_DIR/init-db.sh" >/dev/null
escaped=$(printf '%s' "$MESSAGE_ID" | sed "s/'/''/g")
changed=$(agmsg_sqlite "$DB" "UPDATE messages SET status='$STATUS', handled_at=strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE message_id='$escaped'; SELECT changes();")
[ "$changed" = 1 ] || { echo "message not found: $MESSAGE_ID" >&2; exit 4; }
echo "message_id=$MESSAGE_ID status=$STATUS"
